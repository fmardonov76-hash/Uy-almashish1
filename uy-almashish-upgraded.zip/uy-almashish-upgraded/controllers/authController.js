const jwt = require('jsonwebtoken');
const UserModel = require('../models/User');

function generateToken(user) {
  return jwt.sign(
    { id: user.id, email: user.email, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
}

async function register(req, res) {
  try {
    const { username, email, password } = req.body;

    if (UserModel.findByEmail(email)) {
      return res.status(409).json({ success: false, error: 'Bu email allaqachon ro\'yxatdan o\'tgan' });
    }
    if (UserModel.findByUsername(username)) {
      return res.status(409).json({ success: false, error: 'Bu username band' });
    }

    const user = await UserModel.create({ username, email, password });
    const token = generateToken(user);

    res.status(201).json({
      success: true,
      message: 'Ro\'yxatdan muvaffaqiyatli o\'tdingiz!',
      token,
      user,
    });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ success: false, error: 'Server xatosi' });
  }
}

async function login(req, res) {
  try {
    const { email, password } = req.body;

    const user = UserModel.findByEmail(email);
    if (!user) {
      return res.status(401).json({ success: false, error: 'Email yoki parol noto\'g\'ri' });
    }

    const isMatch = await UserModel.comparePassword(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ success: false, error: 'Email yoki parol noto\'g\'ri' });
    }

    const token = generateToken(user);
    const safeUser = UserModel.sanitize(user);

    res.json({
      success: true,
      message: 'Muvaffaqiyatli kirildi!',
      token,
      user: safeUser,
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ success: false, error: 'Server xatosi' });
  }
}

function me(req, res) {
  res.json({ success: true, user: req.user });
}

module.exports = { register, login, me };
