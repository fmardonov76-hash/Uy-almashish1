const nodemailer = require('nodemailer');
const MessageModel = require('../models/Message');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

async function submitContact(req, res) {
  try {
    const { name, email, phone, message } = req.body;

    const saved = MessageModel.create({ name, email, phone, message });
    console.log(`Yangi xabar saqlandi: ${name} (${email})`);

    try {
      await transporter.sendMail({
        from: `"Uy Almashish Sayti" <${process.env.EMAIL_USER}>`,
        to: process.env.EMAIL_USER,
        subject: `Yangi xabar: ${name}`,
        html: `
          <div style="font-family:Arial,sans-serif;max-width:500px;padding:20px;border:1px solid #ddd;border-radius:10px;">
            <h2 style="color:#2c7a4b;">Uy Almashish — Yangi xabar!</h2>
            <hr/>
            <p><b>Ism:</b> ${name}</p>
            <p><b>Email:</b> <a href="mailto:${email}">${email}</a></p>
            <p><b>Telefon:</b> <a href="tel:${phone}">${phone}</a></p>
            <p><b>Xabar:</b></p>
            <div style="background:#f5f5f5;padding:12px;border-radius:6px;">${message}</div>
            <hr/>
            <p style="color:#888;font-size:12px;">${new Date().toLocaleString('uz-UZ')}</p>
          </div>
        `,
      });
    } catch (emailErr) {
      console.error('Email yuborishda xato:', emailErr.message);
    }

    res.json({ success: true, message: "Xabaringiz qabul qilindi!", data: saved });
  } catch (err) {
    console.error('Contact error:', err);
    res.status(500).json({ success: false, error: 'Server xatosi' });
  }
}

function getMessages(req, res) {
  const messages = MessageModel.findAll();
  res.json({ success: true, data: messages });
}

module.exports = { submitContact, getMessages };
