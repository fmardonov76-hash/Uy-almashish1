# 🏠 Uy Almashish — v2.0 Full-Stack Upgrade

Node.js + Express + Socket.io + JWT Authentication

---

## 📁 Project Structure

```
uy-almashish/
├── server.js                  # Entry point
├── package.json
├── .env                       # Environment variables (DO NOT commit)
├── .env.example
├── .gitignore
│
├── routes/
│   ├── auth.js                # POST /api/auth/register, /login, GET /me
│   └── contact.js             # POST /api/contact, GET /api/contact/messages
│
├── controllers/
│   ├── authController.js      # register, login, me
│   └── contactController.js   # submitContact, getMessages
│
├── models/
│   ├── User.js                # JSON-file user store + bcrypt
│   ├── Message.js             # Contact messages
│   └── ChatMessage.js         # Real-time chat history
│
├── middleware/
│   ├── auth.js                # authMiddleware, adminMiddleware
│   └── validate.js            # Input validation
│
├── sockets/
│   └── chat.js                # Socket.io logic (join, message, typing)
│
├── data/                      # JSON data store (auto-created)
│   ├── users.json
│   ├── messages.json
│   └── chat_messages.json
│
└── public/                    # Static frontend
    ├── index.html
    ├── contact.html
    ├── about.html
    ├── login.html             # ✨ NEW
    ├── register.html          # ✨ NEW
    ├── chat.html              # ✨ NEW (user chat)
    ├── admin.html             # ✨ NEW (admin panel)
    ├── css/
    │   └── styles.css
    ├── js/
    │   └── auth.js            # ✨ Shared auth utility
    └── images/
```

---

## 🚀 Setup Instructions

### 1. Install dependencies

```bash
npm install
```

### 2. Configure environment

```bash
cp .env.example .env
```

Edit `.env`:
```env
PORT=3000
JWT_SECRET=your_very_strong_random_secret_here
JWT_EXPIRES_IN=7d

EMAIL_USER=your_gmail@gmail.com
EMAIL_PASS=your_gmail_app_password

ADMIN_USERNAME=admin
ADMIN_EMAIL=admin@yoursite.uz
ADMIN_PASSWORD=YourStrongPassword123!
```

> **Gmail App Password**: Go to Gmail → Security → 2-Step Verification → App Passwords

### 3. Run the project

```bash
# Production
npm start

# Development (auto-restart)
npm run dev
```

Open: **http://localhost:3000**

---

## 🔑 Authentication

| Endpoint | Method | Body | Description |
|---|---|---|---|
| `/api/auth/register` | POST | `{username, email, password}` | Register new user |
| `/api/auth/login` | POST | `{email, password}` | Login, returns JWT |
| `/api/auth/me` | GET | — | Get current user (requires Bearer token) |

### Admin account
Created automatically on first server start using `.env` values.

Default: `admin@yoursite.uz` / `YourStrongPassword123!`

---

## 💬 Real-time Chat

- Users connect to `/chat.html` after login
- Admin connects to `/admin.html`
- Admin sees all online users in sidebar
- Admin clicks a user to open 1-on-1 chat
- All messages saved to `data/chat_messages.json`
- Typing indicators included

---

## 📧 Contact API

| Endpoint | Method | Auth | Description |
|---|---|---|---|
| `/api/contact` | POST | Public | Submit contact form |
| `/api/contact/messages` | GET | Admin only | View all messages |

---

## 🧪 Postman Testing

### Register
```http
POST http://localhost:3000/api/auth/register
Content-Type: application/json

{
  "username": "testuser",
  "email": "test@example.com",
  "password": "password123"
}
```

### Login
```http
POST http://localhost:3000/api/auth/login
Content-Type: application/json

{
  "email": "test@example.com",
  "password": "password123"
}
```

### Get current user (protected)
```http
GET http://localhost:3000/api/auth/me
Authorization: Bearer YOUR_JWT_TOKEN_HERE
```

### Get admin messages (admin only)
```http
GET http://localhost:3000/api/contact/messages
Authorization: Bearer ADMIN_JWT_TOKEN_HERE
```

---

## 🔐 Security Features

- Passwords hashed with bcrypt (12 salt rounds)
- JWT tokens with expiry
- Rate limiting: 100 req/15min (API), 20 req/15min (auth)
- Input validation on all endpoints
- No hardcoded secrets (dotenv)
- Socket.io connections authenticated via JWT

---

## 🌐 Frontend Pages

| Page | URL | Auth |
|---|---|---|
| Home | `/` | Public |
| Contact | `/contact.html` | Public |
| About | `/about.html` | Public |
| Login | `/login.html` | Guest only |
| Register | `/register.html` | Guest only |
| Chat | `/chat.html` | Logged in |
| Admin Panel | `/admin.html` | Admin only |
