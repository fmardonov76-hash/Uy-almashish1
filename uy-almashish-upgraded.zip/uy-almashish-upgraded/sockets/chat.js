const jwt = require('jsonwebtoken');
const UserModel = require('../models/User');
const ChatMessageModel = require('../models/ChatMessage');

// Track online users: socketId -> { userId, username, role, roomId }
const onlineUsers = new Map();

function getRoomId(userId, adminId) {
  return [userId, adminId].sort().join('_');
}

module.exports = function setupSockets(io) {
  // Authenticate socket connection via JWT
  io.use((socket, next) => {
    const token = socket.handshake.auth.token;
    if (!token) {
      return next(new Error('Authentication required'));
    }
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const user = UserModel.findById(decoded.id);
      if (!user) return next(new Error('User not found'));
      socket.user = UserModel.sanitize(user);
      next();
    } catch (err) {
      next(new Error('Invalid token'));
    }
  });

  io.on('connection', (socket) => {
    const user = socket.user;
    console.log(`[Socket] Connected: ${user.username} (${user.role})`);

    // Register user as online
    onlineUsers.set(socket.id, { ...user, socketId: socket.id });

    // Notify admins of new user
    if (user.role !== 'admin') {
      const adminSockets = [...onlineUsers.values()].filter(u => u.role === 'admin');
      adminSockets.forEach(admin => {
        io.to(admin.socketId).emit('users:update', getOnlineUsers());
      });
    }

    // Admin joins — send list of all online users
    if (user.role === 'admin') {
      socket.emit('users:update', getOnlineUsers());
    }

    // JOIN a chat room (user initiates or admin selects)
    socket.on('chat:join', ({ targetUserId }) => {
      // For admin: targetUserId is the user they want to chat with
      // For user: targetUserId is 'admin' or the actual admin id
      let roomId;
      if (user.role === 'admin') {
        roomId = getRoomId(targetUserId, user.id);
      } else {
        // Find first online admin
        const adminUser = [...onlineUsers.values()].find(u => u.role === 'admin');
        const adminId = adminUser ? adminUser.id : 'admin';
        roomId = getRoomId(user.id, adminId);
      }

      socket.join(roomId);
      socket.currentRoom = roomId;

      // Send message history
      const history = ChatMessageModel.getByRoom(roomId);
      socket.emit('chat:history', history);

      console.log(`[Socket] ${user.username} joined room ${roomId}`);
    });

    // SEND message
    socket.on('chat:message', ({ text }) => {
      if (!socket.currentRoom || !text || !text.trim()) return;

      const msg = ChatMessageModel.create({
        roomId: socket.currentRoom,
        senderId: user.id,
        senderName: user.username,
        senderRole: user.role,
        text: text.trim(),
      });

      io.to(socket.currentRoom).emit('chat:message', msg);
    });

    // TYPING indicator
    socket.on('chat:typing', ({ isTyping }) => {
      if (!socket.currentRoom) return;
      socket.to(socket.currentRoom).emit('chat:typing', {
        username: user.username,
        isTyping,
      });
    });

    // DISCONNECT
    socket.on('disconnect', () => {
      console.log(`[Socket] Disconnected: ${user.username}`);
      onlineUsers.delete(socket.id);

      // Notify admins
      const adminSockets = [...onlineUsers.values()].filter(u => u.role === 'admin');
      adminSockets.forEach(admin => {
        io.to(admin.socketId).emit('users:update', getOnlineUsers());
      });
    });
  });

  function getOnlineUsers() {
    return [...onlineUsers.values()]
      .filter(u => u.role !== 'admin')
      .map(({ socketId, id, username, role }) => ({ socketId, id, username, role }));
  }
};
