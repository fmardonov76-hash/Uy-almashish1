const express = require('express');
const router = express.Router();
const { submitContact, getMessages } = require('../controllers/contactController');
const { validateContact } = require('../middleware/validate');
const { adminMiddleware } = require('../middleware/auth');

router.post('/', validateContact, submitContact);
router.get('/messages', adminMiddleware, getMessages);

module.exports = router;
