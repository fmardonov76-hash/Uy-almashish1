// Shared auth utility for all pages
const Auth = {
  getToken() {
    return localStorage.getItem('ua_token');
  },
  getUser() {
    const u = localStorage.getItem('ua_user');
    return u ? JSON.parse(u) : null;
  },
  setSession(token, user) {
    localStorage.setItem('ua_token', token);
    localStorage.setItem('ua_user', JSON.stringify(user));
  },
  clearSession() {
    localStorage.removeItem('ua_token');
    localStorage.removeItem('ua_user');
  },
  isLoggedIn() {
    return !!this.getToken();
  },
  isAdmin() {
    const u = this.getUser();
    return u && u.role === 'admin';
  },
  logout() {
    this.clearSession();
    window.location.href = '/login.html';
  },
  requireAuth(redirectTo = '/login.html') {
    if (!this.isLoggedIn()) {
      window.location.href = redirectTo;
      return false;
    }
    return true;
  },
  requireAdmin() {
    if (!this.isLoggedIn() || !this.isAdmin()) {
      window.location.href = '/login.html';
      return false;
    }
    return true;
  },
  async apiFetch(url, options = {}) {
    const token = this.getToken();
    const headers = { 'Content-Type': 'application/json', ...options.headers };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch(url, { ...options, headers });
    return res.json();
  },
};

// Inject nav auth state on every page
document.addEventListener('DOMContentLoaded', () => {
  const nav = document.querySelector('nav ul');
  if (!nav) return;

  const user = Auth.getUser();
  // Remove existing auth links to prevent duplicates
  nav.querySelectorAll('.auth-link').forEach(el => el.remove());

  if (user) {
    const chatLi = document.createElement('li');
    chatLi.className = 'auth-link';
    chatLi.innerHTML = `<a href="${user.role === 'admin' ? '/admin.html' : '/chat.html'}">💬 Chat</a>`;
    nav.appendChild(chatLi);

    const logoutLi = document.createElement('li');
    logoutLi.className = 'auth-link';
    logoutLi.innerHTML = `<a href="#" id="logoutBtn">👤 ${user.username} | Chiqish</a>`;
    nav.appendChild(logoutLi);

    document.getElementById('logoutBtn').addEventListener('click', (e) => {
      e.preventDefault();
      Auth.logout();
    });
  } else {
    const loginLi = document.createElement('li');
    loginLi.className = 'auth-link';
    loginLi.innerHTML = `<a href="/login.html">🔐 Kirish</a>`;
    nav.appendChild(loginLi);
  }
});
