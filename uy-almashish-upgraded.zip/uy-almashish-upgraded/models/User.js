const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

const USERS_FILE = path.join(__dirname, '../data/users.json');

function readUsers() {
  if (!fs.existsSync(USERS_FILE)) {
    fs.writeFileSync(USERS_FILE, JSON.stringify([], null, 2));
  }
  return JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
}

function writeUsers(users) {
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
}

const UserModel = {
  findAll() {
    return readUsers();
  },

  findById(id) {
    const users = readUsers();
    return users.find(u => u.id === id) || null;
  },

  findByEmail(email) {
    const users = readUsers();
    return users.find(u => u.email.toLowerCase() === email.toLowerCase()) || null;
  },

  findByUsername(username) {
    const users = readUsers();
    return users.find(u => u.username.toLowerCase() === username.toLowerCase()) || null;
  },

  async create({ username, email, password, role = 'user' }) {
    const users = readUsers();
    const salt = await bcrypt.genSalt(12);
    const hashedPassword = await bcrypt.hash(password, salt);

    const newUser = {
      id: uuidv4(),
      username,
      email: email.toLowerCase(),
      password: hashedPassword,
      role, // 'user' | 'admin'
      createdAt: new Date().toISOString(),
    };

    users.push(newUser);
    writeUsers(users);

    const { password: _, ...userWithoutPassword } = newUser;
    return userWithoutPassword;
  },

  async comparePassword(plainText, hashed) {
    return bcrypt.compare(plainText, hashed);
  },

  sanitize(user) {
    const { password, ...rest } = user;
    return rest;
  },
};

module.exports = UserModel;
