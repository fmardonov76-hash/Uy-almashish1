const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const CHAT_FILE = path.join(__dirname, '../data/chat_messages.json');

function read() {
  if (!fs.existsSync(CHAT_FILE)) {
    fs.writeFileSync(CHAT_FILE, JSON.stringify([], null, 2));
  }
  return JSON.parse(fs.readFileSync(CHAT_FILE, 'utf8'));
}

function write(data) {
  fs.writeFileSync(CHAT_FILE, JSON.stringify(data, null, 2));
}

const ChatMessageModel = {
  getByRoom(roomId) {
    const all = read();
    return all.filter(m => m.roomId === roomId);
  },

  create({ roomId, senderId, senderName, senderRole, text }) {
    const all = read();
    const msg = {
      id: uuidv4(),
      roomId,
      senderId,
      senderName,
      senderRole,
      text,
      timestamp: new Date().toISOString(),
    };
    all.push(msg);
    write(all);
    return msg;
  },

  getAllRooms() {
    const all = read();
    const rooms = {};
    all.forEach(m => {
      if (!rooms[m.roomId]) {
        rooms[m.roomId] = { roomId: m.roomId, messages: [], lastMessage: null };
      }
      rooms[m.roomId].messages.push(m);
      rooms[m.roomId].lastMessage = m;
    });
    return Object.values(rooms);
  },
};

module.exports = ChatMessageModel;
