const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const MESSAGES_FILE = path.join(__dirname, '../data/messages.json');

function readMessages() {
  if (!fs.existsSync(MESSAGES_FILE)) {
    fs.writeFileSync(MESSAGES_FILE, JSON.stringify([], null, 2));
  }
  return JSON.parse(fs.readFileSync(MESSAGES_FILE, 'utf8'));
}

function writeMessages(messages) {
  fs.writeFileSync(MESSAGES_FILE, JSON.stringify(messages, null, 2));
}

const MessageModel = {
  findAll() {
    return readMessages();
  },

  create(data) {
    const messages = readMessages();
    const msg = {
      id: uuidv4(),
      ...data,
      date: new Date().toISOString(),
    };
    messages.push(msg);
    writeMessages(messages);
    return msg;
  },
};

module.exports = MessageModel;
