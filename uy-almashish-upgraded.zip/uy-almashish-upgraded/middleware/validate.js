function validateRegister(req, res, next) {
  const { username, email, password } = req.body;
  const errors = [];

  if (!username || username.trim().length < 3) {
    errors.push('Username kamida 3 ta belgi bo\'lishi kerak');
  }
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    errors.push('Yaroqli email kiriting');
  }
  if (!password || password.length < 6) {
    errors.push('Parol kamida 6 ta belgi bo\'lishi kerak');
  }

  if (errors.length > 0) {
    return res.status(400).json({ success: false, errors });
  }
  next();
}

function validateLogin(req, res, next) {
  const { email, password } = req.body;
  const errors = [];

  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    errors.push('Yaroqli email kiriting');
  }
  if (!password) {
    errors.push('Parol kiritilmadi');
  }

  if (errors.length > 0) {
    return res.status(400).json({ success: false, errors });
  }
  next();
}

function validateContact(req, res, next) {
  const { name, email, phone, message } = req.body;
  const errors = [];

  if (!name || name.trim().length < 2) errors.push('Ism kiritilmadi');
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push('Yaroqli email kiriting');
  if (!phone || phone.trim().length < 7) errors.push('Telefon raqami kiritilmadi');
  if (!message || message.trim().length < 5) errors.push('Xabar juda qisqa');

  if (errors.length > 0) {
    return res.status(400).json({ success: false, errors });
  }
  next();
}

module.exports = { validateRegister, validateLogin, validateContact };
