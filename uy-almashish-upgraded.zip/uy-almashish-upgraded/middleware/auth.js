const jwt = require('jsonwebtoken');
const UserModel = require('../models/User');

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, error: 'Token taqdim etilmadi' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = UserModel.findById(decoded.id);

    if (!user) {
      return res.status(401).json({ success: false, error: 'Foydalanuvchi topilmadi' });
    }

    req.user = UserModel.sanitize(user);
    next();
  } catch (err) {
    return res.status(401).json({ success: false, error: 'Token noto\'g\'ri yoki muddati tugagan' });
  }
}

function adminMiddleware(req, res, next) {
  authMiddleware(req, res, () => {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ success: false, error: 'Ruxsat yo\'q — faqat admin' });
    }
    next();
  });
}

module.exports = { authMiddleware, adminMiddleware };
