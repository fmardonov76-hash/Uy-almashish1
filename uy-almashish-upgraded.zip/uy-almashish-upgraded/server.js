require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const cors = require('cors');
const rateLimit = require('express-rate-limit');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] },
});

// ─── Middleware ────────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rate limiting
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 min
  max: 100,
  message: { success: false, error: 'Juda ko\'p so\'rov. 15 daqiqadan so\'ng urinib ko\'ring.' },
});
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: { success: false, error: 'Juda ko\'p urinish. 15 daqiqadan so\'ng urinib ko\'ring.' },
});

// ─── Static files ──────────────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public')));

// ─── API Routes ────────────────────────────────────────────────
app.use('/api/auth', authLimiter, require('./routes/auth'));
app.use('/api/contact', apiLimiter, require('./routes/contact'));

// ─── Admin seed (creates admin on first start) ─────────────────
const UserModel = require('./models/User');
async function seedAdmin() {
  const existing = UserModel.findByEmail(process.env.ADMIN_EMAIL);
  if (!existing) {
    await UserModel.create({
      username: process.env.ADMIN_USERNAME,
      email: process.env.ADMIN_EMAIL,
      password: process.env.ADMIN_PASSWORD,
      role: 'admin',
    });
    console.log(`✅ Admin yaratildi: ${process.env.ADMIN_EMAIL}`);
  }
}
seedAdmin();

// ─── Socket.io ────────────────────────────────────────────────
require('./sockets/chat')(io);

// ─── SPA fallback ─────────────────────────────────────────────
app.get('*', (req, res) => {
  if (!req.path.startsWith('/api')) {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
  } else {
    res.status(404).json({ success: false, error: 'Route topilmadi' });
  }
});

// ─── Start ─────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`🚀 Server: http://localhost:${PORT}`);
  console.log(`📧 Email: ${process.env.EMAIL_USER}`);
  console.log(`🔐 Admin: ${process.env.ADMIN_EMAIL}`);
});
